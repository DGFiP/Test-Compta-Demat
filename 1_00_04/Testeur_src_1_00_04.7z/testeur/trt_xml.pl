#!/usr/bin/perl

####################################################################################
#                                                                                  /!\ Fichier a enregistrer en utf-8                                                                                       #
####################################################################################

# Modules utilis�s
use strict;
use XML::Parser;
use Getopt::Std;
use File::Copy;
use utf8;
no utf8;

# Extraction des param�tres
our %opts;

require "alto2_fonctions.pl";

# logs en base pg
our $dbhlog;
my $dbh;
our $REQ;
our $log_seq;

# fin logs

getopts( 'hf:T:t:s:a:o:e:n:d', \%opts );

#logs
$dbhlog = &connexion_log( "altoweb2", $dbh );
$log_seq = $opts{n};

#fin logs

# V�rification des param�tres
&verif_param;

# Initialisation des variables globales et tableaux
my $ifile  = $opts{f};      # fichier XML � traiter
my $handle = *FICXML;       # handle du fichier XML
my $debut  = $opts{'t'};    # marqueur de d�but d'enregistrement
my $sep    = $opts{s};      # s�parateur de champs � utiliser
my $flux
    = $opts{'t'};    # balise d'entete d'un enregistrement pour le fichier xml
my $flux1     = $opts{'T'};  # balise d'entete du fichier xml
my $finsstruc = 0;           # fin sous-structure etat-civil (0 =faux, 1=vrai)
my $new_row = 2;     # nouvel enregistrement (0 =faux, 1=vrai, 2 = init)
my $tag     = 0;     # nouvelle balise ouvrante (0 =faux, 1=vrai)
my $elem    = '';    # �l�ment lu en cours
my $svelem  = '';    # sauvegarde de l'�l�ment en cours
my $i       = 0;     # indice des champs dans l'enregistrement complet
my $j       = 0;     # indice des champs dans l'enregistremnt lu
my $l       = 0;     # ligne en cours de lecture dans le fichier input
my $k       = 0;     # gestion des champs absents
my $p       = '';    # pointeur de l'objet XML en cours de traitement
my $data    = '';    # donn�es en cours de traitement par le parser
my $pfx     = '';    # pr�fixe repr�sentatif des sous-structures xml
my $line    = '';    # ligne du fichier en cours de traitement
my $ancetre = '';    # debut xml
my $arbre   = '';    # arbre xml
my %Hattr   = ();    # table de hash des attributs d'une ligne xml
my $lock = 0;  # on n'exploite en d�tail que les enregistrements pas l'entete
my $bug  = 0;  # pour debuger mettre bug=1 sinon bug=0
my %Hf1_fmt   = ();           # Table de hash structure xml
my $rHf1_fmt  = \%Hf1_fmt;    # R�f�rence sur la table de hash structure xml
my $nbfusions = 0;            # Nb de cas sp�ciaux fusion
my $nb_fields = keys %Hf1_fmt;    # nombre de champs du tableau
my $field     = '';               # champ � rechercher dans le tableau
my $defautlocal
    = '';    # traite le cas d'une balise vide avec seult un attribut xml
my $pfx_naisdec
    = '';    # prefixe naissance ou deces pour les attributs de balises vides
my $rHattr_enr = \%Hattr;    # r�f�rence sur la hash table
my @f1_data;
my @entete;                  # liste des champs "fixes"
my @plat;                    # tableau du fichier plat
my @plat_code;               # tableau du fichier plat
my %attr;                    # table de hash des attributs d'un champs
my @ch_plus
    ; # tableau de tableaux  pour les champs en plus sur  ""ligne" " dans le fichier xml
my $ch_plus_ligne = 1;  # rang  de la ligne dans le tableau des champs en plus
my $ch_plus_col   = 0;

our $enc_open = "";     # encodage du fichier de travail
my $est_utf8 = 0;

# Test si fichier XML compress�
my $FIFO = undef;
&test_compress;

my $handle   = *FICXML;             # handle du fichier XML
my $encodage = ChercheEncodage();

&alimTables;                        # chargement du mapping plat <=> xml

$bug = 1 if ( defined $opts{'d'} );

# recherche des champs noms dans la liste pour
# Cr�ation d'une instance de parser
# (demande d'affichage des erreurs avec 2 lignes avant et apr�s)

my $parser = new XML::Parser( ErrorContext => 2 );

# Association m�thode/fonction
$parser->setHandlers(
    Start => \&balise_debut,
    Char  => \&balise_texte,
    End   => \&balise_fin
);

#RG:T: Parsing du fichier  xml pass� en param�tre:E
$parser->parse($handle);

close FICXML;
close OFILE;

#RG:T: Ajout des col en plus pr�sente dans le xml -> plat :I

move( $opts{o}, $opts{o} . "_wks" );

# ici ok ���

open( FIN, "< $enc_open", $opts{o} . "_wks" )
    or die "Impossible de lire le fichier  " . $opts{o} . "_wks";
open( FOUT, "> ", $opts{o} )
    or die "Impossible de lire le fichier  " . $opts{o};
binmode( FOUT, " :encoding(iso-8859-15)" );
select FOUT;

my $uentete           = "";
my $old_champs_entete = 0;

foreach my $ui (
    sort { $rHf1_fmt->{$a}{'plat'} <=> $rHf1_fmt->{$b}{'plat'} }
    keys %Hf1_fmt
    )
{
    if ( ($old_champs_entete) == ( $ui - 1 ) ) {
        if ( $uentete ne "" ) { $uentete .= "|"; }
        $uentete .= $rHf1_fmt->{$ui}{'noeud_plat'};
        &trace( $ui . ": $uentete " );
        $old_champs_entete = $ui;
    }
}

for ( my $u = 1; $u <= $ch_plus_col; $u++ ) {
    $uentete .= "|" . $ch_plus[$u][0];
    &trace( $u . ": $uentete " );
}

print $uentete . "\n";
my $ul      = 0;
my $pourlog = "";
while ( my $u_ligne = <FIN> ) {
    $u_ligne =~ s/\x0D\x0A$//;
    chomp $u_ligne;
    $ul++;

    for ( my $u = 1; $u <= $ch_plus_col; $u++ ) {
        $u_ligne .= "|" . $ch_plus[$u][$ul];

    }

    $u_ligne = &conv_to_iso($u_ligne);
    print "$u_ligne \n";

    &trace($u_ligne);
}
close FOUT;
close FIN;
unlink "$opts{o}\_wks" or &trace("Nettoyage fichier de travail");
open( F, ">  :encoding(latin9)", "${opts{o}}.entete" )
    or die "Impossible d'ouvrir   " . ${ opts {o} } . ".entete en ecriture";
print F $uentete . "\n";
close F;

&maj_log($dbhlog) ;
&deconnexion($dbhlog);

#
# Sous-programmes
#

sub alimTables {

# tables au format    cf doc opencalc pour g�n�rer les lignes en cas de maj
# p�res_cl�s_xml:fils;rang_plat;rang_xml;r�gle_m�tier_�_appliquer;CHAMPS_BASE_POSTGRES
#  champs 4 et 19 <=>>
    my @f1_fmt;
    @f1_fmt = qw(
        journal�JournalCode;1;1;;code_jrnal
        journal�JournalLib;2;2;;lib_jrnal
        journal_ecriture�EcritureNum;3;3;;num_ecr
        journal_ecriture�EcritureDate;4;4;DS;date_cpt
        journal_ecriture_ligne�CompteNum;5;5;NC;num_cpte_gen
        journal_ecriture_ligne�CompteLib;6;6;;lib_cpte_gen
        journal_ecriture_ligne�CompteAuxNum;7;7;;num_cpt_aux
        journal_ecriture_ligne�CompteAuxLib;8;8;;lib_cpt_aux
        journal_ecriture_ligne�Debit;9;9;NU;mtn_debit
        journal_ecriture_ligne�Credit;10;10;NU;mtn_credit
        journal_ecriture�EcritureLib;11;11;;lib_ecriture
        journal_ecriture�PieceRef;12;12;;num_piece
        journal_ecriture�PieceDate;13;13;DS;date_piece
        journal_ecriture�EcritureLet;14;14;;code_lettrage
        journal_ecriture�DateLet;15;15;DS;date_lettrage
        journal_ecriture�Resultat;16;16;;ecr_type
        journal_ecriture�ValidDate;17;17;DS;valid_date
        journal_ecriture_ligne�Montantdevise;18;18;NU;mtn_devise
        journal_ecriture_ligne�Idevise;19;19;;idevise
        journal_ecriture_ligne�Montant;0;20;NU;mtn_debit
        journal_ecriture_ligne�Sens;0;21;;mtn_credit
    );

    foreach my $i (@f1_fmt) {
        my @liste1 = split /;/, uc($i);
        my ( $i_1, $i_2 ) = split /�/, $liste1[0];
        $Hf1_fmt{ $liste1[2] }{'chemin'} = $i_1;
        $Hf1_fmt{ $liste1[2] }{'noeud'}  = $i_2;
        $Hf1_fmt{ $liste1[2] }{'plat'}   = $liste1[1];

        if ( !defined( $liste1[3] ) ) {
            $Hf1_fmt{ $liste1[2] }{'metier'} = " ";
        }
        else {
            $Hf1_fmt{ $liste1[2] }{'metier'} = $liste1[3];
        }
        $Hf1_fmt{ $liste1[2] }{'noeud_plat'} = $liste1[4];
    }

}

sub test_compress {

    open( FICXML, "< $enc_open", "$opts{f}" )
        or die "erreur d'ouverture du fichier  $opts{f}";
    binmode( FICXML, "$enc_open" );
    $enc_open = ":encoding(latin9)";
}

sub arbreXML {
    my @contexte = $p->context;
    shift @contexte;
    shift @contexte;
    $arbre = uc( join( "_", @contexte ) );
}

sub constructionPlat {

    my $indice_xml;    # rang dans l'ordre xml
    my $indice_txt;    # rang dans le fichier plat txt
    my @div;           # liste des codes divergences
    my @txt;           # tableau des champs du fichier txt
    my $v;             # ligne
                       # if ( !defined( $entete[3] ) ) {        return;     }

    &trace("contenu tableau xml :");
    for ( $indice_xml = 1; $indice_xml <= $#plat; $indice_xml++ ) {
        &trace(   $indice_xml
                . "donnee : "
                . $plat[$indice_xml]
                . "donnee code : "
                . $plat_code[$indice_xml] );
    }
    &trace("fin contenu tableau xml :");

    # TODO : AJout col
    for ( $indice_xml = 1; $indice_xml <= $#plat; $indice_xml++ ) {
        $indice_txt = $Hf1_fmt{$indice_xml}{'plat'};
        &trace(   "indice :"
                . $indice_xml
                . "indice plat : "
                . $indice_txt
                . "donnee : "
                . $plat[$indice_xml]
                . "donnee code : "
                . $plat_code[$indice_xml] );
        $txt[$indice_txt] = $plat[$indice_xml];

        # &trace ("txt [".$indice_txt."] =". $txt[$indice_txt]);
    }

  #RG:F: retraitement debit / credit par ligne en pr�sence de Montant/sens :I
  #RG:F: retraitement debit / credit par ligne, sens hors plage D C +1 -1 :E
    if ( defined $plat[21] && defined $plat[20] ) {
        &trace( "Montant : " . $plat[20] . " SENS :" . $plat[21] );
        if ( uc( $plat[21] ) eq "C" || $plat[21] =~ /^\s*\-1\s*$/ ) {
            $txt[10] = $plat[20];
            $txt[9]  = 0;

        }
        elsif ( uc( $plat[21] ) eq "D" || $plat[21] =~ /^\s*\+1\s*$/ ) {
            $txt[9]  = $plat[20];
            $txt[10] = 0;
        }
        else {
            &trace( "Ligne :  $ch_plus_ligne, Valeur SENS incorrecte : "
                    . uc( $plat[21] ) );
            exit 1;
        }
    }

    shift @txt;

    &trace("contenu tableau plat :");
    for ( $indice_xml = 1; $indice_xml <= $#txt; $indice_xml++ ) {
        &trace(
            $indice_xml . "donnee : " . $txt[$indice_xml] . "donnee  : " );
    }

    for ( $indice_xml = 1; $indice_xml <= $#plat; $indice_xml++ ) {

#RG:T:Remise � vide du contenu des balises � chaque fin de ligne d'�criture:I
        $plat[$indice_xml] = undef
            if ( $Hf1_fmt{$indice_xml}{'chemin'} =~ /_ligne$/i );
    }
    my $rep = join( "|", @txt );

    &trace($rep);
    if ( $#plat < 20 ) {
        for ( my $ijk = $#txt; $ijk <= $#plat; $ijk++ ) {
            $rep .= '|';
        }
        &trace( "ligne complete : " . $rep );
    }
    $rep = &conv_to_iso($rep);

    print $rep. "\n";
    $ch_plus_ligne++;

}

sub balise_debut {

# on exploite ici l'architecture des balises xml pas leur contenu
# sauf les attributs qui font parti de la balise :
# cas sp�cifique une balise avec un attribut mais pas de donn�es est ignor� de base ...

    ( $p, $data, %attr ) = @_;
    &trace( "debut : " . $data );

    # utf8::decode($data);
    %Hattr = '';

    if (%attr) {
        foreach my $v ( keys %attr ) {
            $Hattr{$v} = $attr{$v};
        }
    }

    if ( $data =~ /^${flux1}$/ ) {
        $lock = 0;
    }
    elsif ( $data =~ /${debut}/ ) {
        $defautlocal = "";

        # balise xml d'une ligne (journal)
        $new_row     = 1;
        $i           = 0;
        $lock        = 0;
        $pfx         = "";    # data
        $pfx_naisdec = "";
        for ( my $l = 2; $l < 5; $l++ ) { $entete[$l] = ""; }
    }
    else {
        &trace("erreur : $data inattendu ");
    }

    # Nouveau tag ouvrant
    $tag = 1;
}

sub cherche_champs {

    my ( $dataloc, $pfxloc, $pfxdec ) = @_;
    &trace( $dataloc, $pfxloc, $pfxdec );
    foreach my $ii ( keys %Hf1_fmt ) {
        if (   index( $rHf1_fmt->{$ii}{'chemin'}, $pfxloc ) != -1
            && $rHf1_fmt->{$ii}{'noeud'} eq $dataloc
            && index( $rHf1_fmt->{$ii}{'chemin'}, $pfxdec ) != -1 )
        {
            &trace( $ii . "trouve" );
            return $ii;
        }
    }
    return 0;
}

sub cherche_rang {
    my ($dataloc) = @_;
    foreach my $ii ( keys %Hf1_fmt ) {
        if ( index( $rHf1_fmt->{$ii}{'chemin'}, $dataloc ) != -1 ) {
            &trace( $ii . "trouve" );
            return $ii;
        }
    }
    &trace("$dataloc non trouve");
    return 50;

}

sub balise_texte {
    ( $p, $data ) = @_;

    #utf8::decode($data); incompatbile hp-ux
    my $ii = &existe_field;
    if ( $ii == 0 ) {

        #RG:F:prise en compte nouvelle col facultative:I
        $elem = $p->current_element;
        if (   ( $elem !~ /^\s*$/ )
            && ( $data !~ /^\s*$/ )
            && ( $elem ne 'DateCloture' ) )
        {
            &trace("$elem : $data champs nouveau ?");
            my $u_trouve = $ch_plus_col + 1;
            for ( my $u = 1; $u < $ch_plus_col + 1; $u++ ) {
                if ( $ch_plus[$u][0] eq $elem ) {
                    $u_trouve = $u;
                    last;
                }
            }
            if ( $u_trouve > $ch_plus_col ) { $ch_plus_col++; }
            $ch_plus[$u_trouve][0] = $elem;
            $ch_plus[$u_trouve][$ch_plus_ligne] = $data;
            &trace(   "rang $u_trouve ligne  $ch_plus_ligne valeur $data  "
                    . $ch_plus[$u_trouve][0] . ""
                    . $ch_plus[$u_trouve][$ch_plus_ligne] );
        }
        return;
    }
    $data = &reglesMetier( $ii, $data );
    if ( $data !~ /^\s*$/ ) {
        if ( ( $elem ne $svelem ) || ( $elem eq $svelem && $finsstruc == 1 ) )
        {
            $i++;
            if ( $new_row == 1 ) {

                # &constructionPlat;
                @plat      = '';
                @plat_code = '';
                $new_row   = 0;
            }
            $plat[$ii]      = $data;
            $plat_code[$ii] = $Hattr{'code'};
            $svelem         = $elem;
        }
        else {
            if ( defined $plat[$ii] ) {
                $plat[$ii] .= $data;
            }
            else {
                $plat[$ii]      = $data;
                $plat_code[$ii] = $Hattr{'code'};
            }
            $svelem = $elem;
        }
        $tag       = 0;
        $finsstruc = 0;
    }
    &trace(
        "ii :" . $ii . " plat :" . $plat[$ii] . "code : " . $plat_code[$ii] );
}

sub balise_fin {
    ( $p, $data ) = @_;

    # code sp�cifique selon le type de balise de fin d'enregistrements
    #utf8::decode($data); incompatible hp-ux
    if ( $data =~ /^ligne$/i ) {
        &constructionPlat;
    }
}

sub prepare_fusion {
    return;

}

sub reglesMetier {

    my ( $ii, $valeurEntree, $metierforce ) = @_;
    my $valeurSortie = $valeurEntree;
    my $metier;
    if ( defined($metierforce) ) {
        $metier = $metierforce;
    }
    else {
        $metier = $Hf1_fmt{$ii}{'metier'};
    }
    my $heure;

#RG:F:Date Souple format accept� AAAA-MM-JJ ou AAAA-MM-JJThh;mm;ss  :I
#RG:F:Date Souple format accept� AAAA-MM-JJ ou AAAA-MM-JJThh;mm;ss  :I
#RG:F:Montant  sous la forme +- en debut ou en fin accept�:I
#RG:F:Montant  sous la forme num�rique avec s�parateur . uniquement accept�:I
#RG:F:Num�ro de compte sous la forme num�rique sur 3 positions, suivi alphanumerique:I

    if ( $metier eq 'DS' ) {
        if (( $valeurEntree !~ m/^\s*[0-9]{4}-[0-9]{2}-[0-9]{2}\s*$/ )
            && ( $valeurEntree
                !~ m/^\s*[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\s*$/
            )
            )
        {

            &trace( "Date incorrecte $valeurEntree \n", "X" );

        }
    }
    elsif ( $metier eq 'NU' ) {
        $valeurSortie =~ tr/,/./;
        if ( $valeurSortie !~ m/^[\+\-]*[0-9]{1,}\.*[0-9]*[\+\-]*$/ ) {
            &trace( "Somme incorrecte $valeurEntree \n", "X" );
        }

    }
    elsif ( $metier eq 'NC' ) {
        if ( $valeurEntree !~ m/^[0-9]{3}[0-9a-zA-Z]*$/ ) {
            &trace( "Num Compte incorrect $valeurEntree \n", "X" );
        }

    }

    return $valeurSortie;

}

sub trace {
    my ( $mess, $trace ) = @_;
    if ($bug) {
        &erreur( "E", ":ligne " . $ch_plus_ligne . ":" . $mess );
    }
    else {
        &erreur( $trace, ":ligne " . $ch_plus_ligne . ":" . $mess )
            if defined($trace);
    }
}

sub existe_field {
    $line = '';
    $elem = $p->current_element;
    &arbreXML;
    foreach my $ii ( keys %Hf1_fmt ) {
        my $field_fmt
            = $rHf1_fmt->{$ii}{'chemin'} . '_' . $rHf1_fmt->{$ii}{'noeud'};
        if ( $field_fmt eq $arbre ) {
            $line = $p->current_line;
            return $ii;
        }
    }
    if (   $line eq ''
        && $p->current_element ne $flux
        && $lock != 1
        && index( $p->current_line, $arbre ) != -1 )
    {
        &trace(   "\n "
                . $p->current_line
                . " balise ["
                . $p->current_element
                . "] inconnue, lock: $lock , --${arbre}--     \n " );
    }
    return 0;

}

END { unlink $FIFO if defined $FIFO }

